/* ==============================================
   YASHWANTH GOWDA BM — PORTFOLIO JAVASCRIPT
   ============================================== */

'use strict';

// ── PAGE LOADER ────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('loader');
    if (loader) {
      loader.classList.add('hidden');
      document.body.style.overflow = '';
      initHeroAnimations();
    }
  }, 2000);
});
document.body.style.overflow = 'hidden';

// ── CUSTOM CURSOR ──────────────────────────────
const cursor     = document.getElementById('cursor');
const cursorTrail = document.getElementById('cursor-trail');
let mx = 0, my = 0, tx = 0, ty = 0;

document.addEventListener('mousemove', e => {
  mx = e.clientX; my = e.clientY;
  if (cursor) { cursor.style.left = mx + 'px'; cursor.style.top = my + 'px'; }
});

function animateTrail() {
  tx += (mx - tx) * 0.12;
  ty += (my - ty) * 0.12;
  if (cursorTrail) { cursorTrail.style.left = tx + 'px'; cursorTrail.style.top = ty + 'px'; }
  requestAnimationFrame(animateTrail);
}
animateTrail();

document.querySelectorAll('a, button, .trait-card, .ach-card, .club-card, .hobby-card, .project-card, .gallery-item').forEach(el => {
  el.addEventListener('mouseenter', () => {
    if (cursor) { cursor.style.width = '22px'; cursor.style.height = '22px'; cursor.style.background = '#fff'; }
    if (cursorTrail) { cursorTrail.style.width = '52px'; cursorTrail.style.height = '52px'; }
  });
  el.addEventListener('mouseleave', () => {
    if (cursor) { cursor.style.width = '14px'; cursor.style.height = '14px'; cursor.style.background = 'var(--blue)'; }
    if (cursorTrail) { cursorTrail.style.width = '36px'; cursorTrail.style.height = '36px'; }
  });
});

// ── SCROLL PROGRESS BAR ────────────────────────
const scrollBar = document.getElementById('scroll-bar');
window.addEventListener('scroll', () => {
  const pct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
  if (scrollBar) scrollBar.style.width = pct + '%';
}, { passive: true });

// ── NAVBAR SCROLL BEHAVIOR ─────────────────────
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 50);
}, { passive: true });

// ── MOBILE NAV TOGGLE ──────────────────────────
const navToggle = document.getElementById('navToggle');
const navLinks  = document.getElementById('navLinks');
if (navToggle && navLinks) {
  navToggle.addEventListener('click', () => {
    navLinks.classList.toggle('open');
  });
  navLinks.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => navLinks.classList.remove('open'));
  });
}

// ── BACK TO TOP ────────────────────────────────
const backToTop = document.getElementById('backToTop');
window.addEventListener('scroll', () => {
  if (backToTop) backToTop.classList.toggle('visible', window.scrollY > 400);
}, { passive: true });
if (backToTop) {
  backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

// ── HERO ANIMATIONS ────────────────────────────
function initHeroAnimations() {
  const revealEls = document.querySelectorAll('.hero-content .reveal-up');
  revealEls.forEach((el, i) => {
    setTimeout(() => { el.classList.add('in'); }, i * 120 + 100);
  });
  const nameWords = document.querySelectorAll('.name-word');
  nameWords.forEach((w, i) => {
    w.style.opacity = '0';
    w.style.transform = 'translateY(50px)';
    w.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
    w.style.transitionDelay = (i * 0.18 + 0.2) + 's';
    setTimeout(() => {
      w.style.opacity = '1';
      w.style.transform = 'translateY(0)';
    }, 50);
  });
}

// ── CIRCUIT CANVAS ─────────────────────────────
const canvas = document.getElementById('circuit-canvas');
if (canvas) {
  const ctx = canvas.getContext('2d');
  let W, H, nodes = [], lines = [];

  function resizeCanvas() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
    buildCircuit();
  }

  function buildCircuit() {
    nodes = [];
    lines = [];
    const count = Math.floor((W * H) / 25000);
    for (let i = 0; i < count; i++) {
      nodes.push({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
        r: Math.random() * 2.5 + 1,
        opacity: Math.random() * 0.6 + 0.2,
        pulse: Math.random() * Math.PI * 2,
      });
    }
  }

  function drawCircuit() {
    ctx.clearRect(0, 0, W, H);
    const t = Date.now() * 0.001;

    // Draw connections
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 160) {
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          const alpha = (1 - dist / 160) * 0.3;
          ctx.strokeStyle = `rgba(0, 212, 255, ${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      }
    }

    // Draw nodes
    nodes.forEach(n => {
      n.pulse += 0.03;
      const glowAlpha = (Math.sin(n.pulse) * 0.3 + 0.6) * n.opacity;
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0, 212, 255, ${glowAlpha})`;
      ctx.fill();

      n.x += n.vx;
      n.y += n.vy;
      if (n.x < 0 || n.x > W) n.vx *= -1;
      if (n.y < 0 || n.y > H) n.vy *= -1;
    });

    requestAnimationFrame(drawCircuit);
  }

  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();
  drawCircuit();
}

// ── PARTICLES ──────────────────────────────────
const particlesContainer = document.getElementById('particles');
if (particlesContainer) {
  for (let i = 0; i < 28; i++) {
    const p = document.createElement('div');
    const size = Math.random() * 3 + 1;
    const delay = Math.random() * 6;
    const dur   = Math.random() * 8 + 8;
    const x     = Math.random() * 100;
    p.style.cssText = `
      position:absolute; border-radius:50%; pointer-events:none;
      width:${size}px; height:${size}px;
      background:rgba(0,212,255,${Math.random() * 0.5 + 0.1});
      left:${x}%; top:${Math.random() * 100}%;
      animation: floatParticle ${dur}s ${delay}s ease-in-out infinite alternate;
      box-shadow:0 0 ${size * 3}px rgba(0,212,255,0.4);
    `;
    particlesContainer.appendChild(p);
  }

  const style = document.createElement('style');
  style.textContent = `
    @keyframes floatParticle {
      0%   { transform: translateY(0) translateX(0) scale(1); opacity: 0.3; }
      50%  { transform: translateY(-120px) translateX(20px) scale(1.5); opacity: 0.7; }
      100% { transform: translateY(-60px) translateX(-15px) scale(0.8); opacity: 0.2; }
    }
  `;
  document.head.appendChild(style);
}

// ── SCROLL REVEAL ──────────────────────────────
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const delay = el.dataset.delay ? parseFloat(el.dataset.delay) * 0.12 : 0;
      setTimeout(() => el.classList.add('in'), delay * 1000);
      revealObserver.unobserve(el);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right').forEach(el => {
  revealObserver.observe(el);
});

// ── COUNTER ANIMATION ──────────────────────────
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const target = parseInt(el.dataset.target);
      let current = 0;
      const step = Math.max(1, Math.floor(target / 40));
      const timer = setInterval(() => {
        current = Math.min(current + step, target);
        el.textContent = current;
        if (current >= target) clearInterval(timer);
      }, 40);
      counterObserver.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.stat-num[data-target]').forEach(el => {
  counterObserver.observe(el);
});

// ── PROGRESS BAR ANIMATION ────────────────────
const progObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const fill = entry.target.querySelector('.prog-fill');
      if (fill) {
        const w = fill.dataset.width;
        setTimeout(() => { fill.style.width = w + '%'; }, 400);
      }
      progObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.4 });

document.querySelectorAll('.progress-block').forEach(el => progObserver.observe(el));

// ── GALLERY FILTER ────────────────────────────
document.querySelectorAll('.gf-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.gf-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const filter = btn.dataset.filter;
    document.querySelectorAll('.gallery-item').forEach(item => {
      if (filter === 'all' || item.dataset.cat === filter) {
        item.style.display = '';
        item.style.opacity = '0';
        setTimeout(() => { item.style.transition = 'opacity 0.4s'; item.style.opacity = '1'; }, 50);
      } else {
        item.style.opacity = '0';
        setTimeout(() => { item.style.display = 'none'; }, 400);
      }
    });
  });
});

// ── CONTACT FORM ──────────────────────────────
function handleFormSubmit(e) {
  e.preventDefault();
  const form    = document.getElementById('contactForm');
  const success = document.getElementById('formSuccess');
  const btn     = form.querySelector('.form-btn');

  btn.disabled = true;
  btn.querySelector('span').textContent = 'Sending...';

  setTimeout(() => {
    form.reset();
    btn.disabled = false;
    btn.querySelector('span').textContent = 'Send Message';
    if (success) { success.style.display = 'block'; setTimeout(() => { success.style.display = 'none'; }, 4000); }
  }, 1200);
}
window.handleFormSubmit = handleFormSubmit;

// ── SMOOTH SECTION SCROLLING ──────────────────
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const target = document.querySelector(link.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ── NAV LINK ACTIVE STATE ─────────────────────
const sections = document.querySelectorAll('section[id]');
const navLinkEls = document.querySelectorAll('.nav-link');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.id;
      navLinkEls.forEach(link => {
        link.style.color = link.getAttribute('href') === `#${id}` ? 'var(--blue)' : '';
      });
    }
  });
}, { threshold: 0.3 });

sections.forEach(s => sectionObserver.observe(s));

// ── TRAIT CARD TILT ───────────────────────────
document.querySelectorAll('.trait-card, .ach-card, .project-card').forEach(card => {
  card.addEventListener('mousemove', e => {
    const r = card.getBoundingClientRect();
    const cx = (e.clientX - r.left) / r.width  - 0.5;
    const cy = (e.clientY - r.top)  / r.height - 0.5;
    card.style.transform = `perspective(600px) rotateY(${cx * 10}deg) rotateX(${-cy * 10}deg) translateY(-6px)`;
  });
  card.addEventListener('mouseleave', () => {
    card.style.transform = '';
  });
});

// ── GALLERY LIGHTBOX ──────────────────────────
document.querySelectorAll('.gallery-item').forEach(item => {
  item.addEventListener('click', () => {
    const label = item.querySelector('.gp-label')?.textContent || 'Gallery';
    const icon  = item.querySelector('.gp-icon')?.textContent || '🖼️';
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position:fixed;inset:0;background:rgba(3,8,14,0.96);z-index:9999;
      display:flex;align-items:center;justify-content:center;
      cursor:pointer;animation:fadeIn 0.3s ease;
    `;
    overlay.innerHTML = `
      <div style="text-align:center;color:var(--white);">
        <div style="font-size:80px;margin-bottom:20px;">${icon}</div>
        <div style="font-family:var(--font-head);font-size:22px;color:var(--blue);letter-spacing:0.1em;">${label}</div>
        <div style="font-family:var(--font-ui);font-size:13px;color:var(--text-dim);margin-top:10px;letter-spacing:0.2em;">CLICK TO CLOSE</div>
      </div>
    `;
    const fadeStyle = document.createElement('style');
    fadeStyle.textContent = '@keyframes fadeIn{from{opacity:0}to{opacity:1}}';
    document.head.appendChild(fadeStyle);
    overlay.addEventListener('click', () => {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.3s';
      setTimeout(() => { overlay.remove(); fadeStyle.remove(); }, 300);
    });
    document.body.appendChild(overlay);
  });
});

// ── TYPING EFFECT ON HERO QUOTE ───────────────
function typeWriter(el, text, speed = 35) {
  el.textContent = '';
  let i = 0;
  const timer = setInterval(() => {
    if (i < text.length) {
      el.textContent += text.charAt(i);
      i++;
    } else {
      clearInterval(timer);
    }
  }, speed);
}

// Activate typing when hero quote enters view
const quoteEl = document.querySelector('.hero-quote');
if (quoteEl) {
  const quoteText = 'Every little step I make builds the future I dream of.';
  const qObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        quoteEl.innerHTML = '<span class="quote-mark">"</span> <span class="qt"></span> <span class="quote-mark">"</span>';
        typeWriter(quoteEl.querySelector('.qt'), quoteText);
        qObs.unobserve(quoteEl);
      }
    });
  }, { threshold: 0.8 });
  qObs.observe(quoteEl);
}

// ── MAGNETIC BUTTONS ──────────────────────────
document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('mousemove', e => {
    const r  = btn.getBoundingClientRect();
    const cx = e.clientX - (r.left + r.width  / 2);
    const cy = e.clientY - (r.top  + r.height / 2);
    btn.style.transform = `translate(${cx * 0.2}px, ${cy * 0.2}px) translateY(-2px)`;
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.transform = '';
  });
});

// ── GLITCH TEXT EFFECT ON HERO NAME ───────────
const heroName = document.querySelector('.hero-name');
if (heroName) {
  heroName.addEventListener('mouseenter', () => {
    heroName.style.animation = 'none';
    const accent = heroName.querySelector('.name-accent');
    if (accent) {
      accent.style.filter = 'blur(1px)';
      setTimeout(() => { accent.style.filter = ''; }, 150);
    }
  });
}

// ── GLOW FOLLOW MOUSE ─────────────────────────
document.querySelectorAll('.project-card').forEach(card => {
  const glow = card.querySelector('.proj-glow');
  card.addEventListener('mousemove', e => {
    const r  = card.getBoundingClientRect();
    const x  = e.clientX - r.left;
    const y  = e.clientY - r.top;
    if (glow) {
      glow.style.left = (x - 100) + 'px';
      glow.style.top  = (y - 100) + 'px';
      glow.style.opacity = '1';
    }
  });
  card.addEventListener('mouseleave', () => {
    if (glow) glow.style.opacity = '0.6';
  });
});

console.log('%c⚡ Yashwanth Gowda BM | Portfolio %c v1.0.0 ', 
  'background:#00d4ff;color:#03080e;font-weight:900;font-size:14px;padding:6px 10px;', 
  'background:#0a1622;color:#00d4ff;font-size:12px;padding:6px 10px;');
